//stu_num.h
#include <stdio.h>
int stu_num();
