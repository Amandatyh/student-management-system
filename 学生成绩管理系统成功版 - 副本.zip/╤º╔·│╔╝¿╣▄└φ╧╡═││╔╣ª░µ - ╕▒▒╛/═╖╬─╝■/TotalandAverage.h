//TotalandAverage.h
#include <stdio.h>
void TotalandAverage(int score[],int n);
