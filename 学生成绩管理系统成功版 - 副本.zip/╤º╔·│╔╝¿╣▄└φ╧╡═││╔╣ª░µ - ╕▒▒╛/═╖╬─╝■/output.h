//output.h
#include <stdio.h>
void output(long num[],int score[],int n);
