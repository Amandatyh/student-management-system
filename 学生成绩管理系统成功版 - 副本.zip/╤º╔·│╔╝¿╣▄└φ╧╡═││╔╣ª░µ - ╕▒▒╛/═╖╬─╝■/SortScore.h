//SortScore.h
#include <stdio.h>
void SortScore(long num[],int score[],int n); 
