//menu.h
#include <stdio.h>
int menu();
