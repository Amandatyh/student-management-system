//ReadScore.h
#include <stdio.h>
void ReadScore(long num[],int score[],int n);
