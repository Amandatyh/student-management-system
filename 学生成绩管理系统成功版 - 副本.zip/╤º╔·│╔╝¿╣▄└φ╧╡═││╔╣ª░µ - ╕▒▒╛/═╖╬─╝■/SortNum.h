//SortNum.h
#include <stdio.h>
void SortNum(long num[],int score[],int n);
