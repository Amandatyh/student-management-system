//ListRecord.h
#include <stdio.h>
void ListRecord(long num[],int score[],int n);
