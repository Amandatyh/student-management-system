//LinSearch.h
#include <stdio.h>
void LinSearch(long num[],int score[],int n);
