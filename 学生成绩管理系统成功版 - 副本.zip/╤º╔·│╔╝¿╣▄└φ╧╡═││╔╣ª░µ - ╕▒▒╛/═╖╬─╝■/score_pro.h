//score_pro.h
#include <stdio.h>
void score_pro(int score[],int n);
